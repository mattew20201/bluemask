

# ⚠️ WARNING ⚠️

#### DO NOT ASK FOR PHISHLETS.
#### DO NOT ASK FOR HELP CREATING PHISHLETS.
#### DO NOT ASK TO FIX PHISHLETS.
#### DO NOT ADVERTISE OR TRY TO SELL PHISHLETS.
#### EXPECT A BAN OTHERWISE. THANK YOU!



----
---

# REPORT ONLY BUGS OR FEATURE SUGGESTIONS.

**Describe the bug:**
(Provide a clear and concise description of what the bug is)

**Steps to reproduce the behavior:**
1. Go to '...'
2. Click on '....'
3. See error

**Expected behavior:**
(A clear and concise description of what you expected to happen)

**Screenshots:**
(If applicable, add screenshots to help explain your problem)

**System Info:**
- OS: [e.g. Ubuntu 20.04]
- Evilginx Version [e.g. 2.3.0]
